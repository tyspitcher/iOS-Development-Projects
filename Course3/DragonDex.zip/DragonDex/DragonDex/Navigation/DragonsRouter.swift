//
//  DragonsRouter.swift
//  DragonDex
//
//  Created by Logan Steven Bartell on 12/4/25.
//
import Foundation
import SwiftUI

// TODO: Create a Navigation Router for navigating Dragon views
